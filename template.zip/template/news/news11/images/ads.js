var showHiddenAd=false;
function OTnews_ads(str){
switch (str){
case 'ot0001':
document.writeln("<a href=\"www.qjbaby.com\"><img src=\"http:\/\/www.900.la\/u\/2010\/12\/05\/1291555276YLYJ.gif\" border=\"0\"><\/a>");
break;

case 'ot0002':
document.writeln("<a href=\"www.qjbaby.com\"><img src=\"http:\/\/www.900.la\/u\/2010\/12\/06\/1291574615hCXC.gif\" border=\"0\"><\/a>");
break;

case 'ot0003':
document.writeln("<embed height=\"90\" width=\"960\" flashvars=\"bannerWidth=960&bannerHeight=90&bannerSID=http:\/\/img.uu1001.cn\/x\/2010-12-05\/21-12\/2010-12-05_85c7dbd6e990e23df56f282aac4a1648_0.xml&bannerXML=&bannerLink=http%3A%2F%2Fwww%2Eqjbaby%2Ecom&dataSource=&bid=14933245&appSource=default\" wmode=\"transparent\" allowscriptaccess=\"always\" quality=\"high\" name=\"14933245\" id=\"14933245\" style=\"\" src=\"http:\/\/img.uu1001.cn\/bcv3.swf?v=336d66e2f5b2ed8613b5bb90ad60471506dad868\" type=\"application\/x-shockwave-flash\"\/><\/embed>");
document.writeln("");
document.writeln("<embed height=\"60\" width=\"960\" flashvars=\"bannerWidth=960&bannerHeight=60&bannerSID=http:\/\/img.uu1001.cn\/x\/2010-12-05\/22-06\/2010-12-05_2be362cb2bfa6fac374460d7d1438e9d_0.xml&bannerXML=&bannerLink=http%3A%2F%2Fshop63207478%2Etaobao%2Ecom%2F&dataSource=&bid=14936170&appSource=default\" wmode=\"transparent\" allowscriptaccess=\"always\" quality=\"high\" name=\"14936170\" id=\"14936170\" style=\"\" src=\"http:\/\/img.uu1001.cn\/bcv3.swf?v=336d66e2f5b2ed8613b5bb90ad60471506dad868\" type=\"application\/x-shockwave-flash\"\/><\/embed>");
break;

case 'ot0004':
if (showHiddenAd==true){
document.writeln("<table width=\'100%\' cellpadding=\'0\' cellspacing=\'0\' style=\'border:1px #eaeaea solid; margin-top:5px;\'>");
document.writeln("<colgroup span=\'5\' width=\'20%\' align=\'center\' \/>");
document.writeln("<tr>");
document.writeln("    <td style=\'padding:3px;\'><a href=\"http:\/\/www.kuge616.com\/\" target=\"_blank\" style=\"color: green\">�����ʳ������<\/a><\/td>");
document.writeln("    <td style=\'padding:3px;\'><a href=\"http:\/\/www.kuge6.com\/\" target=\"_blank\"  style=\"color: green\">�����ʵ�����<\/a><\/td>");
document.writeln("    <td style=\'padding:3px;\'><a href=\"http:\/\/www.kuge616.com\/huabao.html\" target=\"_blank\"  style=\"color: green\">����Ա�����<\/a><\/td>");
document.writeln("    <td style=\'padding:3px;\'><span style=\'color:#b2b1b1;\'>����ۣ�ȫվ���ֹ��<b>30\/��<\/b><\/span><\/td>");
document.writeln("    <td style=\'padding:3px;\'><a href=\"http:\/\/www.oneti.cn\/\" target=\"_blank\">��������<\/a>��<a href=\"http:\/\/www.oneti.cn\/\" target=\"_blank\">�������¹���ϵͳ<\/a><\/td>");
document.writeln("<\/tr>");
document.writeln("<tr>");
document.writeln("    <td style=\'padding:3px;\'><a href=\"http:\/\/shopFree.oneti.cn\/\" target=\"_blank\">�����̳�ϵͳ��Ѱ�V1.0��ʾ<\/a><\/td>");
document.writeln("    <td style=\'padding:3px;\'><a href=\"http:\/\/shop.oneti.cn\/\" target=\"_blank\">�����̳�ϵͳ��ҵ��V1.0��ʾ<\/a><\/td>");
document.writeln("    <td style=\'padding:3px;\'><span style=\'color:#b2b1b1;\'>����ۣ�ȫվ���ֹ��<b>30\/��<\/b><\/span><\/td>");
document.writeln("    <td style=\'padding:3px;\'><span style=\'color:#b2b1b1;\'>����ۣ�ȫվ���ֹ��<b>30\/��<\/b><\/span><\/td>");
document.writeln("    <td style=\'padding:3px;\'><span style=\'color:#b2b1b1;\'>����ۣ�ȫվ���ֹ��<b>30\/��<\/b><\/span><\/td>");
document.writeln("<\/tr>");
document.writeln("<tr>");
document.writeln("    <td style=\'padding:3px;\'><a href=\"http:\/\/www.oneti.cn\/NewsMode2\" style=\'color:#2222FF;\' target=\"_blank\">�������¹���ϵͳV1.0��ʾ<\/a><\/td>");
document.writeln("    <td style=\'padding:3px;\'><a href=\"http:\/\/www.oneti.cn\/NewsMode3\" style=\'color:#2222FF;\' target=\"_blank\">�������¹���ϵͳ���Ա������У�<\/a><\/td>");
document.writeln("    <td style=\'padding:3px;\'><a href=\"http:\/\/www.oneti.cn\/NewsMode4\" style=\'color:#2222FF;\' target=\"_blank\">�������¹���ϵͳ���Ա��͵��̣�<\/a><\/td>");
document.writeln("    <td style=\'padding:3px;\'><a href=\"http:\/\/www.oneti.cn\/NewsMode5\" style=\'color:#2222FF;\' target=\"_blank\">�������¹���ϵͳ��Ƶ���ƹ㣩<\/a><\/td>");
document.writeln("    <td style=\'padding:3px;\'><span style=\'color:#b2b1b1;\'>����ۣ�ȫվ���ֹ��<b>30\/��<\/b><\/span><\/td>");
document.writeln("<\/tr>");
document.writeln("<\/table>");
}
break;

case 'ot0005':
if (showHiddenAd==true){
document.writeln("<iframe border=\"0\" vspace=\"0\" hspace=\"0\" marginwidth=\"0\" marginheight=\"0\" framespacing=\"0\" frameborder=\"0\" scrolling=\"no\" width=\"960\" height=\"60\" src=\"http:\/\/www.oneti.cn\/ads.asp?adID=5\"><\/iframe>");
}
break;

case 'ot0006':
if (showHiddenAd==true){
document.writeln("<iframe border=\"0\" vspace=\"0\" hspace=\"0\" marginwidth=\"0\" marginheight=\"0\" framespacing=\"0\" frameborder=\"0\" scrolling=\"no\" width=\"728\" height=\"90\" src=\"http:\/\/www.oneti.cn\/ads.asp?adID=6\"><\/iframe>");
}
break;

case 'ot0007':
if (showHiddenAd==true){
document.writeln("<iframe border=\"0\" vspace=\"0\" hspace=\"0\" marginwidth=\"0\" marginheight=\"0\" framespacing=\"0\" frameborder=\"0\" scrolling=\"no\" width=\"728\" height=\"90\" src=\"http:\/\/www.oneti.cn\/ads.asp?adID=7\"><\/iframe>");
}
break;

case 'ot0008':
if (showHiddenAd==true){
document.writeln("<iframe border=\"0\" vspace=\"0\" hspace=\"0\" marginwidth=\"0\" marginheight=\"0\" framespacing=\"0\" frameborder=\"0\" scrolling=\"no\" width=\"250\" height=\"250\" src=\"http:\/\/www.oneti.cn\/ads.asp?adID=8\"><\/iframe>");
}
break;

case 'ot0009':
document.writeln("<iframe border=\"0\" vspace=\"0\" hspace=\"0\" marginwidth=\"0\" marginheight=\"0\" framespacing=\"0\" frameborder=\"0\" scrolling=\"no\" width=\"250\" height=\"250\" src=\"http:\/\/www.oneti.cn\/ads.asp?adID=9\"><\/iframe>");
break;

case 'ot0010':
document.writeln("<iframe border=\"0\" vspace=\"0\" hspace=\"0\" marginwidth=\"0\" marginheight=\"0\" framespacing=\"0\" frameborder=\"0\" scrolling=\"no\" width=\"640\" height=\"60\" src=\"http:\/\/www.oneti.cn\/ads.asp?adID=10\"><\/iframe>");
break;

case 'ot0011':
document.writeln("<a href=\"http:\/\/count.chanet.com.cn\/click.cgi?a=348464&d=93683&u=&e=\" target=\"_blank\"><IMG SRC=\"http:\/\/file.chanet.com.cn\/image.cgi?a=348464&d=93683&u=&e=\" width=\"250\" height=\"250\"  border=\"0\"><\/a>");
break;

case 'ot0012':
if (showHiddenAd==true){
document.writeln("<iframe border=\"0\" vspace=\"0\" hspace=\"0\" marginwidth=\"0\" marginheight=\"0\" framespacing=\"0\" frameborder=\"0\" scrolling=\"no\" width=\"250\" height=\"250\" src=\"http:\/\/www.oneti.cn\/ads.asp?adID=12\"><\/iframe>");
}
break;

case 'ot0013':
if (showHiddenAd==true){
document.writeln("<iframe border=\"0\" vspace=\"0\" hspace=\"0\" marginwidth=\"0\" marginheight=\"0\" framespacing=\"0\" frameborder=\"0\" scrolling=\"no\" width=\"960\" height=\"60\" src=\"http:\/\/www.oneti.cn\/ads.asp?adID=13\"><\/iframe>");
}
break;

case 'ot0014':
document.writeln("<embed height=\"192\" width=\"250\" flashvars=\"bannerWidth=250&bannerHeight=192&bannerSID=http:\/\/img.uu1001.cn\/x\/2010-12-05\/21-29\/2010-12-05_fef7b58c06482c9351c86eb6f5bc84af_0.xml&bannerXML=&bannerLink=http%3A%2F%2Fwww%2Eqjbaby%2Ecom&dataSource=&bid=14934195&appSource=default\" wmode=\"transparent\" allowscriptaccess=\"always\" quality=\"high\" name=\"14934195\" id=\"14934195\" style=\"\" src=\"http:\/\/img.uu1001.cn\/bcv3.swf?v=336d66e2f5b2ed8613b5bb90ad60471506dad868\" type=\"application\/x-shockwave-flash\"\/><\/embed>");
break;

case 'ot0015':
document.writeln("<iframe border=\"0\" vspace=\"0\" hspace=\"0\" marginwidth=\"0\" marginheight=\"0\" framespacing=\"0\" frameborder=\"0\" scrolling=\"no\" width=\"250\" height=\"250\" src=\"http:\/\/www.oneti.cn\/ads.asp?adID=15\"><\/iframe>");
break;

case 'ot0016':
document.writeln("<iframe border=\"0\" vspace=\"0\" hspace=\"0\" marginwidth=\"0\" marginheight=\"0\" framespacing=\"0\" frameborder=\"0\" scrolling=\"no\" width=\"640\" height=\"60\" src=\"http:\/\/www.oneti.cn\/ads.asp?adID=16\"><\/iframe>");
break;

case 'ot0017':
document.writeln("<iframe border=\"0\" vspace=\"0\" hspace=\"0\" marginwidth=\"0\" marginheight=\"0\" framespacing=\"0\" frameborder=\"0\" scrolling=\"no\" width=\"300\" height=\"250\" src=\"http:\/\/www.oneti.cn\/ads.asp?adID=17\"><\/iframe>");
break;

case 'ot0018':
if (showHiddenAd==true){
document.writeln("");
}
break;

}
}